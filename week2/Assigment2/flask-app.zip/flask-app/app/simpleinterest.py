def simple_interest(principal, rate, period):
    """
    A function to evaluete simple interest
    """
    interest = (principal * rate * period)/ 100

    return interest